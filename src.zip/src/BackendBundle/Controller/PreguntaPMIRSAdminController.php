<?php

namespace BackendBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController;

class PreguntaPMIRSAdminController extends CRUDController
{

}
