<?php

namespace BackendBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController;

class ComponentePMIRSAdminController extends CRUDController
{

}
